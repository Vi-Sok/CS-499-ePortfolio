# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object):
    """
    CRUD operations for the AAC Animal collection in MongoDB.
    """

    def __init__(self, username, password):
        """
        Initialize the MongoDB client using username/password 
        received from the Dash application.
        """

        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        # Build the authenticated MongoDB URI
        uri = f"mongodb://{username}:{password}@{HOST}:{PORT}"

        # Connect to MongoDB
        self.client = MongoClient(uri)

        # Select database and collection
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # ----------------------------------------------------------------------
    # Create (C)
    # ----------------------------------------------------------------------
    def create(self, data):
        """
        Insert a document into the AAC animals collection.
        :param data: dictionary representing the document to insert
        :return: True if insert successful, False otherwise
        """
        if data is None:
            raise Exception("Nothing to save, because data parameter is empty")

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except Exception as e:
            print("An error occurred while inserting document:", e)
            return False

    # ----------------------------------------------------------------------
    # Read (R)
    # ----------------------------------------------------------------------
    def read(self, query=None, projection=None):
        if query is None:
            query = {}
        try:
            cursor = self.collection.find(query, projection)
            return list(cursor)
        except Exception as e:
            print("An error occurred while reading documents:", e)
            return []

    # ----------------------------------------------------------------------
    # Update (U)
    # ----------------------------------------------------------------------
    def update(self, query, update_data, many=False):
        """
        Update document(s) in the animals collection.
        :param query: filter dictionary for selecting documents
        :param update_data: fields to update (used with $set)
        :param many: True updates many documents, False updates one
        :return: number of modified documents
        """
        if query is None or not isinstance(query, dict):
            raise Exception("query parameter must be a non-empty dictionary")
        if update_data is None or not isinstance(update_data, dict):
            raise Exception("update_data parameter must be a non-empty dictionary")

        try:
            update_doc = {"$set": update_data}

            if many:
                result = self.collection.update_many(query, update_doc)
            else:
                result = self.collection.update_one(query, update_doc)

            return result.modified_count
        except Exception as e:
            print("An error occurred while updating documents:", e)
            return 0

    # ----------------------------------------------------------------------
    # Delete (D)
    # ----------------------------------------------------------------------
    def delete(self, query, many=False):
        """
        Delete document(s) from the animals collection.
        :param query: filter dictionary for selecting documents
        :param many: True deletes many documents, False deletes one
        :return: number of deleted documents
        """
        if query is None or not isinstance(query, dict):
            raise Exception("query parameter must be a non-empty dictionary")

        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)

            return result.deleted_count
        except Exception as e:
            print("An error occurred while deleting documents:", e)
            return 0