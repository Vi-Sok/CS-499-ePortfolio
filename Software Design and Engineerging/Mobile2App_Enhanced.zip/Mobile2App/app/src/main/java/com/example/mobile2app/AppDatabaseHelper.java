package com.example.mobile2app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "mobile2app.db";
    private static final int DB_VERSION = 2;

    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password"; // plaintext is okay for class rubric demo (not production)

    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_OWNER = "owner_username";

    public static final String TABLE_SETTINGS = "settings";
    public static final String COL_SETTINGS_ID = "id";
    public static final String COL_SETTINGS_OWNER = "owner_username";
    public static final String COL_SMS_ENABLED = "sms_enabled";

    public AppDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE NOT NULL, "
                + COL_PASSWORD + " TEXT NOT NULL"
                + ")";

        String createInventory = "CREATE TABLE " + TABLE_INVENTORY + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_ITEM_QTY + " INTEGER NOT NULL CHECK(" + COL_ITEM_QTY + " >= 0), "
                + COL_ITEM_OWNER + " TEXT NOT NULL"
                + ")";

        String createSettings = "CREATE TABLE " + TABLE_SETTINGS + " ("
                + COL_SETTINGS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_SETTINGS_OWNER + " TEXT UNIQUE NOT NULL, "
                + COL_SMS_ENABLED + " INTEGER NOT NULL DEFAULT 0"
                + ")";

        db.execSQL(createUsers);
        db.execSQL(createInventory);
        db.execSQL(createSettings);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        if (userExists(username)) return false;

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long rowId = db.insert(TABLE_USERS, null, values);

        if (rowId != -1) {
            ContentValues settings = new ContentValues();
            settings.put(COL_SETTINGS_OWNER, username);
            settings.put(COL_SMS_ENABLED, 0);
            db.insert(TABLE_SETTINGS, null, settings);
        }

        return rowId != -1;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        boolean valid = c.moveToFirst();
        c.close();
        return valid;
    }

    public long addInventoryItem(String ownerUsername, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_OWNER, ownerUsername);
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, qty);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    public ArrayList<InventoryAdapter.InventoryItem> getInventoryItems(String ownerUsername) {
        ArrayList<InventoryAdapter.InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(TABLE_INVENTORY,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY},
                COL_ITEM_OWNER + "=?",
                new String[]{ownerUsername},
                null, null,
                COL_ITEM_ID + " DESC");

        while (c.moveToNext()) {
            int id = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_ID));
            String name = c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME));
            int qty = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_QTY));
            list.add(new InventoryAdapter.InventoryItem(id, name, qty));
        }
        c.close();
        return list;
    }

    public boolean deleteInventoryItem(String ownerUsername, int itemId) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + "=? AND " + COL_ITEM_OWNER + "=?",
                new String[]{String.valueOf(itemId), ownerUsername}
        );
        return rows > 0;
    }

    public boolean updateInventoryItem(String ownerUsername, int itemId, String newName, int newQty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, newName);
        values.put(COL_ITEM_QTY, newQty);

        int rows = db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + "=? AND " + COL_ITEM_OWNER + "=?",
                new String[]{String.valueOf(itemId), ownerUsername}
        );
        return rows > 0;
    }

    public boolean isSmsAlertsEnabled(String ownerUsername) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_SETTINGS,
                new String[]{COL_SMS_ENABLED},
                COL_SETTINGS_OWNER + "=?",
                new String[]{ownerUsername},
                null, null, null);

        boolean enabled = false;
        if (c.moveToFirst()) {
            enabled = c.getInt(c.getColumnIndexOrThrow(COL_SMS_ENABLED)) == 1;
        }
        c.close();
        return enabled;
    }

    public void setSmsAlertsEnabled(String ownerUsername, boolean enabled) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_SMS_ENABLED, enabled ? 1 : 0);

        int rows = db.update(TABLE_SETTINGS, values,
                COL_SETTINGS_OWNER + "=?",
                new String[]{ownerUsername});

        if (rows == 0) {
            ContentValues insertValues = new ContentValues();
            insertValues.put(COL_SETTINGS_OWNER, ownerUsername);
            insertValues.put(COL_SMS_ENABLED, enabled ? 1 : 0);
            db.insert(TABLE_SETTINGS, null, insertValues);
        }
    }
}
