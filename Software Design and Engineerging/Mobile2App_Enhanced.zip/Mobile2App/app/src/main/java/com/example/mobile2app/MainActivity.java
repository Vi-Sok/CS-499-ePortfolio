package com.example.mobile2app;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String currentUser = SessionManager.getLoggedInUsername(this);
        Class<?> destination = (currentUser != null && !currentUser.trim().isEmpty())
                ? InventoryActivity.class
                : LoginActivity.class;

        startActivity(new Intent(this, destination));
        finish();
    }
}
