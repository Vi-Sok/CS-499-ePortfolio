package com.example.mobile2app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnInventoryItemActionListener {

    private TextInputEditText etItemName, etQuantity;
    private MaterialButton btnAddToGrid;
    private FloatingActionButton fabAddItem;

    private final ArrayList<InventoryAdapter.InventoryItem> items = new ArrayList<>();
    private InventoryAdapter adapter;

    private AppDatabaseHelper db;
    private String currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new AppDatabaseHelper(this);
        currentUser = SessionManager.getLoggedInUsername(this);

        if (currentUser == null || currentUser.trim().isEmpty()) {
            Toast.makeText(this, "Please log in first.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        etItemName = findViewById(R.id.etItemName);
        etQuantity = findViewById(R.id.etQuantity);
        btnAddToGrid = findViewById(R.id.btnAddToGrid);
        fabAddItem = findViewById(R.id.fabAddItem);

        RecyclerView rv = findViewById(R.id.rvInventory);
        rv.setLayoutManager(new GridLayoutManager(this, 1));
        adapter = new InventoryAdapter(items, this);
        rv.setAdapter(adapter);

        MaterialButton btnSmsSettings = findViewById(R.id.btnSmsSettings);
        if (btnSmsSettings != null) {
            btnSmsSettings.setOnClickListener(v ->
                    startActivity(new Intent(InventoryActivity.this, SmsActivity.class)));
        }

        btnAddToGrid.setOnClickListener(v -> addItem());

        fabAddItem.setOnClickListener(v -> {
            if (etItemName != null) {
                etItemName.requestFocus();
                showKeyboard(etItemName);
            } else {
                Toast.makeText(this, "Add fields not found (check IDs in XML).", Toast.LENGTH_SHORT).show();
            }
        });

        loadItemsFromDatabase();
    }

    private void loadItemsFromDatabase() {
        items.clear();
        items.addAll(db.getInventoryItems(currentUser));
        adapter.notifyDataSetChanged();
    }

    private void addItem() {
        String name = etItemName.getText() != null ? etItemName.getText().toString().trim() : "";
        String qtyStr = etQuantity.getText() != null ? etQuantity.getText().toString().trim() : "";

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Enter an item name.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(qtyStr)) {
            Toast.makeText(this, "Enter a quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (qty < 0) {
            Toast.makeText(this, "Quantity cannot be negative.", Toast.LENGTH_SHORT).show();
            return;
        }

        long rowId = db.addInventoryItem(currentUser, name, qty);
        if (rowId == -1) {
            Toast.makeText(this, "Failed to save item.", Toast.LENGTH_SHORT).show();
            return;
        }

        loadItemsFromDatabase();

        etItemName.setText("");
        etQuantity.setText("");
        etItemName.requestFocus();

        if (qty == 0 && db.isSmsAlertsEnabled(currentUser)) {
            Toast.makeText(this, "Inventory alert trigger reached (qty = 0).", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onDeleteClicked(InventoryAdapter.InventoryItem item, int position) {
        boolean deleted = db.deleteInventoryItem(currentUser, item.id);
        if (deleted) {
            loadItemsFromDatabase();
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemClicked(InventoryAdapter.InventoryItem item, int position) {
        showEditDialog(item);
    }

    private void showEditDialog(InventoryAdapter.InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Item");

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = 40;
        container.setPadding(pad, 20, pad, 10);

        EditText etName = new EditText(this);
        etName.setHint("Item name");
        etName.setText(item.name);

        EditText etQty = new EditText(this);
        etQty.setHint("Quantity");
        etQty.setInputType(InputType.TYPE_CLASS_NUMBER);
        etQty.setText(String.valueOf(item.qty));

        container.addView(etName);
        container.addView(etQty);

        builder.setView(container);
        builder.setPositiveButton("Save", null);
        builder.setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newName = etName.getText().toString().trim();
            String qtyStr = etQty.getText().toString().trim();

            if (newName.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Name and quantity are required", Toast.LENGTH_SHORT).show();
                return;
            }

            int newQty;
            try {
                newQty = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newQty < 0) {
                Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated = db.updateInventoryItem(currentUser, item.id, newName, newQty);
            if (updated) {
                loadItemsFromDatabase();
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();

                if (newQty == 0 && db.isSmsAlertsEnabled(currentUser)) {
                    Toast.makeText(this, "Inventory alert trigger reached (qty = 0).", Toast.LENGTH_LONG).show();
                }

                dialog.dismiss();
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }
}
