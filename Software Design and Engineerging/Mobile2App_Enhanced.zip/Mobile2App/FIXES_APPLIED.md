# Mobile2App fixes applied

## Build and dependency fixes
- Replaced the module `compileSdk` block with standard AGP syntax: `compileSdk = 36`
- Kept `targetSdk = 36`
- Lowered `minSdk` to 24 for broader emulator/device compatibility
- Added missing `androidx.recyclerview:recyclerview` dependency via the version catalog

## Navigation/session fixes
- MainActivity now sends signed-in users straight to InventoryActivity
- Login and account creation now call `finish()` after navigating to prevent going back to the login screen
- SmsActivity now guards against access when no user is logged in

## Inventory/data fixes
- Prevented negative quantities in both add and edit flows
- Added a database-level quantity check (`CHECK(quantity >= 0)`)
- Restricted update/delete actions so they only affect the logged-in user's items
- Fixed the edit dialog so validation errors no longer close the dialog immediately

## UI cleanups
- Switched the inventory item card to `MaterialCardView`
- Added basic autofill hints for username/password fields

## Note
- I could not run a full Gradle/Android build in this environment because the container has no internet access for Gradle downloads.
