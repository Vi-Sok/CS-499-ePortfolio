package com.example.mobile2app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private TextView tvPermissionStatus;
    private Button btnRequestSmsPermission;
    private Switch switchSmsAlerts;

    private AppDatabaseHelper db;
    private String currentUser;

    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updatePermissionUi();

                if (isGranted) {
                    Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                    switchSmsAlerts.setEnabled(true);
                } else {
                    Toast.makeText(this, "SMS permission denied. App will continue without SMS alerts.", Toast.LENGTH_LONG).show();
                    switchSmsAlerts.setChecked(false);
                    switchSmsAlerts.setEnabled(false);

                    if (!currentUser.isEmpty()) {
                        db.setSmsAlertsEnabled(currentUser, false);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        db = new AppDatabaseHelper(this);
        currentUser = SessionManager.getLoggedInUsername(this);

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        btnRequestSmsPermission = findViewById(R.id.btnRequestSmsPermission);
        switchSmsAlerts = findViewById(R.id.switchSmsAlerts);

        btnRequestSmsPermission.setOnClickListener(v -> requestSmsPermission());

        if (currentUser != null && !currentUser.trim().isEmpty()) {
            boolean savedSmsEnabled = db.isSmsAlertsEnabled(currentUser);
            switchSmsAlerts.setChecked(savedSmsEnabled);
        }

        switchSmsAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (hasSmsPermission()) {
                if (currentUser != null && !currentUser.trim().isEmpty()) {
                    db.setSmsAlertsEnabled(currentUser, isChecked);
                }
                Toast.makeText(this, isChecked ? "SMS alerts enabled" : "SMS alerts disabled", Toast.LENGTH_SHORT).show();
            } else {
                // If permission not granted, do not allow enabling feature
                if (isChecked) {
                    switchSmsAlerts.setChecked(false);
                    Toast.makeText(this, "Grant SMS permission first", Toast.LENGTH_SHORT).show();
                }
            }
        });

        updatePermissionUi();
    }

    private void requestSmsPermission() {
        if (hasSmsPermission()) {
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            updatePermissionUi();
            return;
        }

        requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionUi() {
        boolean granted = hasSmsPermission();

        if (granted) {
            tvPermissionStatus.setText("SMS Permission Status: Granted");
            btnRequestSmsPermission.setText("SMS Permission Granted");
            btnRequestSmsPermission.setEnabled(false);
            switchSmsAlerts.setEnabled(true);
        } else {
            tvPermissionStatus.setText("SMS Permission Status: Not Granted");
            btnRequestSmsPermission.setText("Enable SMS Permission");
            btnRequestSmsPermission.setEnabled(true);
            switchSmsAlerts.setEnabled(false);
        }
    }
}